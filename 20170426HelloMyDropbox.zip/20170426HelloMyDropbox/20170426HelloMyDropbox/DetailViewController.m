//
//  DetailViewController.m
//  20170426HelloMyDropbox
//
//  Created by user35 on 2017/4/26.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "DetailViewController.h"
#import <ObjectiveDropboxOfficial.h>

@interface DetailViewController ()

{ DBUserClient *client;}
@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;

@end

@implementation DetailViewController

- (void)configureView {
    // Update the user interface for the detail item.
    if (self.detailItem) {
        self.detailDescriptionLabel.text = [self.detailItem description];
    }
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self configureView];
    
    //Prepare client
    client = [DBClientsManager authorizedClient]; //與MasterViewController.m是同一個client
    
    if (_detailItem == nil) {
        return;
    }
    
    NSString *fullFilePathName = [NSString stringWithFormat:@"/%@",_detailItem];
    
    [[client.filesRoutes downloadData:fullFilePathName]setResponseBlock:^(DBFILESFileMetadata * _Nullable result, DBFILESDownloadError * _Nullable routeError, DBRequestError * _Nullable networkError, NSData * _Nullable fileData) {
       
        if (result) {
            NSLog(@"Download success: %@", result);
            
            UIImage *image = [UIImage imageWithData:fileData];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.resultImageView.image = image;
            });
            
        }else{
            NSLog(@"Download fail: %@",routeError);
        }
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Managing the detail item

- (void)setDetailItem:(NSDate *)newDetailItem {
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
        
        // Update the view.
        [self configureView];
    }
}


@end
