//
//  MasterViewController.m
//  20170426HelloMyDropbox
//
//  Created by user35 on 2017/4/26.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "MasterViewController.h"
#import "DetailViewController.h"
#import <ObjectiveDropboxOfficial.h>
#import "AppDelegate.h"

@interface MasterViewController ()
{ DBUserClient *client; }

@property NSMutableArray *objects;
@end

@implementation MasterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    self.navigationItem.leftBarButtonItem = self.editButtonItem;
//
//    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
//    self.navigationItem.rightBarButtonItem = addButton;
    self.detailViewController = (DetailViewController *)[[self.splitViewController.viewControllers lastObject] topViewController];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(startDropBoxFunction) name:LOGIN_SUCCESS_NOTIFICATION object:nil];
    
//    [self checkIfShouldLogin];//若單獨放這，首次登入的登入畫面會出不來
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self checkIfShouldLogin];
    });
    
    
    
}

-(void)checkIfShouldLogin{
    
    if ([DBClientsManager authorizedClient] == nil) { //Need to Login
        [DBClientsManager authorizeFromController:[UIApplication sharedApplication]
                                       controller:self
                                          openURL:^(NSURL * _Nonnull url) {
        //Tradition Method
        [[UIApplication sharedApplication] openURL:url];
        //New Method
//        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil]; //非同步
                                              
        }]; //authorizeFromController叫出登入畫面 //self登入畫面顯示於目前畫面
    }else{
        //Logged in already  若已經登入就不會再跳出登入畫面
        [self startDropBoxFunction];
    }
}

-(void)startDropBoxFunction{
    
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
    self.navigationItem.rightBarButtonItem = addButton;

    //Prepare DropBox Support
    client = [DBClientsManager authorizedClient];
    [self dowlondFileList];
}

-(void)dowlondFileList{
     [[client.filesRoutes listFolder:@""] setResponseBlock:^(DBFILESListFolderResult * _Nullable result, DBFILESListFolderError * _Nullable routeError, DBRequestError * _Nullable networkError) {
         
         NSLog(@"Total %ld files.",result.entries.count); //entries是檔案的相關資料  //背景運作
         
         dispatch_async(dispatch_get_main_queue(), ^{
             //Prepare object array
             if (_objects == nil) {
                 _objects = [NSMutableArray new];
             }else{
                 [_objects removeAllObjects];
             }
             //Put filenames into objects
             for (DBFILESMetadata *file in result.entries) {
                 [_objects addObject:file.name];
             }
             [self.tableView reloadData];  //ui有關
         });
     }];
}

- (void)viewWillAppear:(BOOL)animated {
    self.clearsSelectionOnViewWillAppear = self.splitViewController.isCollapsed;
    [super viewWillAppear:animated];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)insertNewObject:(id)sender {
    
    NSString *sourceFilePath = [[NSBundle mainBundle]pathForResource:@"redheart.png" ofType:nil];
    
    NSString *fullFilePathName = [NSString stringWithFormat:@"/%@.jpg",[NSDate date]];
    
    [[client.filesRoutes uploadUrl:fullFilePathName
                          inputUrl:sourceFilePath] setResponseBlock:^(DBFILESFileMetadata * _Nullable result, DBFILESUploadError * _Nullable routeError, DBRequestError * _Nullable networkError) {
         if (result) { //屬於背景執行
             NSLog(@"Upload success. %@",result);
             [self dowlondFileList]; //整個重抓清單，避免檔案清單跟實況不相符
         }else{
             NSLog(@"Upload fail: %@",routeError);
         }
    }];
    
    
//    if (!self.objects) {
//        self.objects = [[NSMutableArray alloc] init];
//    }
//    [self.objects insertObject:[NSDate date] atIndex:0];
//    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
//    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}


#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
//        NSDate *object = self.objects[indexPath.row];
        NSString *fileNmae = self.objects[indexPath.row];
        DetailViewController *controller = (DetailViewController *)[[segue destinationViewController] topViewController];  //topViewController可想像是property user看得到的(在storyboard是Detail，其實跟root是同一個)
//        [controller setDetailItem:object];
        [controller setDetailItem:fileNmae];
        controller.navigationItem.leftBarButtonItem = self.splitViewController.displayModeButtonItem;  //控制左上角的按鈕
        controller.navigationItem.leftItemsSupplementBackButton = YES; //navigationBar的左上角，共存原本的按鈕和自己建的
    }
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.objects.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];

//    NSDate *object = self.objects[indexPath.row];
    NSString *filename = self.objects[indexPath.row]; //換成檔名
//    cell.textLabel.text = [object description];
    cell.textLabel.text = filename;
    return cell;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        NSString *fullFilePathName = [NSString stringWithFormat:@"/%@",_objects[indexPath.row]];
        [[client.filesRoutes delete_:fullFilePathName]setResponseBlock:^(DBFILESMetadata * _Nullable result, DBFILESDeleteError * _Nullable routeError, DBRequestError * _Nullable networkError) {
            if (result) {
                NSLog(@"Delete success: %@",result);
                [self dowlondFileList];
            }else{
                NSLog(@"Delete fail: %@",routeError);
            }
        }];
//        [self.objects removeObjectAtIndex:indexPath.row];
//        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}


@end
