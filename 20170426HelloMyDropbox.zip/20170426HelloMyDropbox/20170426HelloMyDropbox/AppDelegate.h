//
//  AppDelegate.h
//  20170426HelloMyDropbox
//
//  Created by user35 on 2017/4/26.
//  Copyright © 2017年 user35. All rights reserved.
//

#import <UIKit/UIKit.h>
#define LOGIN_SUCCESS_NOTIFICATION @"LOGIN_SUCCESS_NOTIFICATION"


//#define PI 3.14159
//#define BASE_URL @"http://xxx.com"
//#define LOGIN_URL [BASE_URL stringByAppendingPathComponent:@"login.php"]
//#define LOGOUT_URL [BASE_URL stringByAppendingPathComponent:@"logout.php"]

//swift
//let pi = 3.14159
//let login_url = base_url + "login.php"


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

