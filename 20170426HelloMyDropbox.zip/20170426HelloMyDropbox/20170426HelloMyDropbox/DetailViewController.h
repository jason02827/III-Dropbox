//
//  DetailViewController.h
//  20170426HelloMyDropbox
//
//  Created by user35 on 2017/4/26.
//  Copyright © 2017年 user35. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

//@property (strong, nonatomic) NSDate *detailItem;
@property (strong, nonatomic) NSString *detailItem;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@end

